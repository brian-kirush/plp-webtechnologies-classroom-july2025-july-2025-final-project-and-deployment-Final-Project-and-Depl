# Multipage Website Project

This is a simple multipage website built with **HTML5, CSS3, and JavaScript**.

## Pages
- `index.html` → Home page with dark mode toggle.
- `about.html` → About page.
- `contact.html` → Contact page with form validation.

## Features
- Responsive design.
- Dark mode support.
- Custom JavaScript form validation.

## Deployment
You can deploy this project using GitHub Pages:
1. Push the project to a GitHub repo.
2. Go to **Settings > Pages**.
3. Select the branch (e.g., `main`) and root folder.
4. Save, and your site will be live!